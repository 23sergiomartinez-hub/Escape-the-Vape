# Escape the Vape

Web app estática para GitHub Pages.

## Publicarla con GitHub Pages

1. Crea un repositorio nuevo en GitHub, por ejemplo `escape-the-vape`.
2. Sube `index.html` a la raíz del repositorio.
3. En el repositorio entra en **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Pulsa **Save**.
7. GitHub generará una dirección parecida a:

`https://TU-USUARIO.github.io/escape-the-vape/`

Después puedes insertar esa dirección en Google Sites.
